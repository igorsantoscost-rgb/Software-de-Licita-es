from flask import (Blueprint, render_template, redirect, url_for,
                   request, flash, send_from_directory, abort, jsonify, session)
from flask_login import login_required, current_user
from app.models import (Licitacao, Documento, ItemLicitacao, Cliente,
                        STATUS_CHOICES, PORTAL_CHOICES, TIPOS_DOC_LICITACAO_UNICOS,
                        ComentarioLicitacao, ObservacaoApoio)
from app import db
from app.capag import consultar as consultar_capag, municipios_por_uf, UFS, significado as capag_significado
from datetime import datetime
import os, re, uuid, requests

lic_bp = Blueprint("lic", __name__, url_prefix="/licitacoes")

UPLOAD_FOLDER = "/app/uploads"

ESFERA_CHOICES = ["federal", "estadual", "municipal", "consorcio"]


def _aplicar_capag(lic):
    """Le esfera/UF/municipio do formulario, salva na licitacao e consulta a
    nota CAPAG correspondente (quando aplicavel)."""
    esfera = (request.form.get("esfera", "") or "").strip().lower()
    uf = (request.form.get("uf", "") or "").strip().upper()
    municipio = (request.form.get("municipio", "") or "").strip()

    if esfera not in ESFERA_CHOICES:
        esfera = ""
    if esfera in ("federal", "consorcio"):
        # Consórcio público não tem nota CAPAG própria no Tesouro
        uf, municipio = "", ""
    elif esfera == "estadual":
        municipio = ""

    lic.esfera = esfera or None
    lic.uf = uf or None
    lic.municipio = municipio or None

    resultado = consultar_capag(esfera, uf, municipio)
    if resultado:
        lic.capag_nota = resultado["nota"]
        lic.capag_ambito = resultado["ambito"]
        lic.capag_local = resultado["local"]
        lic.capag_referencia = resultado["referencia"]
        lic.capag_consultado_em = datetime.utcnow()
    else:
        lic.capag_nota = None
        lic.capag_ambito = None
        lic.capag_local = None
        lic.capag_referencia = None
        lic.capag_consultado_em = datetime.utcnow() if esfera else None


def _valor_form(nome):
    """Le um valor em reais do formulario ('1.234,56' ou '1234.56')."""
    bruto = (request.form.get(nome, "") or "").strip().replace("R$", "").strip()
    if not bruto:
        return None
    if "," in bruto:
        bruto = bruto.replace(".", "").replace(",", ".")
    try:
        return float(bruto)
    except ValueError:
        return None


def _url_voltar(somente_painel=False):
    """Tela de lista (painel/calendario, com filtros) de onde o usuario veio."""
    url = session.get("voltar_url") or ""
    if not url.startswith("/") or url.startswith("//"):
        return url_for("main.painel")
    if somente_painel and not url.startswith("/painel"):
        return url_for("main.painel")
    return url


def _pode_ver(licitacao):
    return current_user.pode_ver_cliente(licitacao.cliente_id)


def _salvar_arquivo(f, licitacao_id):
    """Salva um arquivo enviado e retorna o caminho no disco."""
    pasta = os.path.join(UPLOAD_FOLDER, str(licitacao_id))
    os.makedirs(pasta, exist_ok=True)
    ext = os.path.splitext(f.filename)[1]
    nome_salvo = f"{uuid.uuid4().hex}{ext}"
    caminho = os.path.join(pasta, nome_salvo)
    f.save(caminho)
    return caminho


def _processar_uploads_form(lic_id):
    """Le os arquivos do form (edital, termo_referencia, outros[]) e cria os Documentos.
    Para edital/termo_referencia, substitui o arquivo anterior se houver um novo."""
    # Slots unicos: edital, termo_referencia
    for tipo in TIPOS_DOC_LICITACAO_UNICOS:
        f = request.files.get(tipo)
        if f and f.filename:
            # remove o anterior desse tipo (slot unico, sempre o mais recente vale)
            anterior = Documento.query.filter_by(licitacao_id=lic_id, tipo=tipo).all()
            for doc_antigo in anterior:
                # o arquivo substituido vai para a lixeira de uploads (30 dias)
                from app import lixeira
                lixeira.enviar_documento(doc_antigo, "documento", "Substituído por um arquivo novo",
                                         usuario_id=current_user.id)
                db.session.delete(doc_antigo)
            caminho = _salvar_arquivo(f, lic_id)
            doc = Documento(
                licitacao_id=lic_id,
                tipo=tipo,
                nome_original=f.filename,
                caminho=caminho,
                tamanho=os.path.getsize(caminho),
                enviado_por=current_user.id,
            )
            db.session.add(doc)

    # Lista livre: outros[] (varios arquivos, sem limite, nunca substitui)
    for f in request.files.getlist("outros"):
        if not f.filename:
            continue
        caminho = _salvar_arquivo(f, lic_id)
        doc = Documento(
            licitacao_id=lic_id,
            tipo="outros",
            nome_original=f.filename,
            caminho=caminho,
            tamanho=os.path.getsize(caminho),
            enviado_por=current_user.id,
        )
        db.session.add(doc)


# ─── Lista / painel (redireciona para main) ──────────────────────────────────

@lic_bp.route("/nova", methods=["GET", "POST"])
@login_required
def nova():
    if not current_user.is_assessor():
        abort(403)
    clientes = Cliente.query.order_by(Cliente.nome).all()
    if request.method == "POST":
        data_str = request.form.get("data_disputa", "")
        data_disputa = None
        if data_str:
            try:
                data_disputa = datetime.strptime(data_str, "%Y-%m-%dT%H:%M")
            except ValueError:
                pass
        lic = Licitacao(
            cliente_id=int(request.form["cliente_id"]),
            orgao_licitante=request.form["orgao_licitante"].strip(),
            numero_pregao=request.form["numero_pregao"].strip(),
            uasg=request.form.get("uasg", "").strip(),
            portal=request.form.get("portal", "").strip(),
            data_disputa=data_disputa,
            status="agendada",
            objeto=request.form.get("objeto", "").strip(),
            link_edital=request.form.get("link_edital", "").strip(),
            valor_estimado=_valor_form("valor_estimado"),
        )
        db.session.add(lic)
        db.session.commit()
        _aplicar_capag(lic)
        _processar_uploads_form(lic.id)
        db.session.commit()
        # Notifica cliente e assessores por e-mail
        from app.email_service import notificar_nova_licitacao
        try:
            notificar_nova_licitacao(lic)
        except Exception:
            pass  # Nao trava o cadastro se o e-mail falhar
        flash("Licitacao criada.", "ok")
        return redirect(url_for("lic.detalhe", id=lic.id))
    return render_template("form_licitacao.html", clientes=clientes,
                           status_choices=STATUS_CHOICES, portal_choices=PORTAL_CHOICES, lic=None,
                           tipos_doc_unicos=TIPOS_DOC_LICITACAO_UNICOS, docs_existentes={},
                           ufs=UFS, esfera_choices=ESFERA_CHOICES, municipios_uf=[])


@lic_bp.route("/<int:id>")
@login_required
def detalhe(id):
    lic = Licitacao.query.get_or_404(id)
    if not _pode_ver(lic):
        abort(403)
    if current_user.is_assessor() and lic.comentario_cliente_pendente_em:
        lic.comentario_cliente_pendente_em = None  # assessor abriu a licitacao: comentario visto
        db.session.commit()
    docs_existentes = {d.tipo: d for d in lic.documentos if d.tipo in TIPOS_DOC_LICITACAO_UNICOS}
    # Parametros da disputa: so os itens com palavras-chave do cliente
    from app.classificador_cliente import itens_do_cliente, grupos_mistos_licitacao
    itens_visiveis, itens_ocultos, palavras_cliente = itens_do_cliente(lic.cliente, lic.itens)
    grupos_mistos, itens_fora_ramo = grupos_mistos_licitacao(lic.cliente, lic.itens)
    todos_itens = request.args.get("todos_itens") == "1"
    return render_template("detalhe_licitacao.html", lic=lic,
                           status_choices=STATUS_CHOICES, portal_choices=PORTAL_CHOICES,
                           capag_significado=capag_significado(lic.capag_nota),
                           docs_existentes=docs_existentes,
                           itens_lista=lic.itens if todos_itens else itens_visiveis,
                           itens_ocultos=len(itens_ocultos), todos_itens=todos_itens,
                           palavras_cliente=palavras_cliente,
                           grupos_mistos=grupos_mistos, itens_fora_ramo=itens_fora_ramo,
                           favorita=any(f.user_id == current_user.id for f in lic.favoritos))


@lic_bp.route("/capag/municipios")
@login_required
def capag_municipios():
    """Lista (JSON) de municipios com CAPAG para a UF informada — usada pelo
    seletor de municipio no formulario."""
    uf = (request.args.get("uf", "") or "").strip().upper()
    return jsonify(municipios_por_uf(uf))


@lic_bp.route("/capag/atualizar", methods=["POST"])
@login_required
def capag_atualizar():
    """Baixa do Tesouro Nacional a versao mais recente das notas CAPAG
    (estados e municipios) e atualiza a base local."""
    if not current_user.is_assessor():
        abort(403)
    from app.capag_import import importar_tudo
    voltar = request.form.get("voltar") or url_for("lic.nova")
    try:
        res = importar_tudo()
    except Exception as e:
        flash(f"Falha ao atualizar a base CAPAG: {e}", "erro")
        return redirect(voltar)
    if res["erros"]:
        flash("Base CAPAG atualizada parcialmente. "
              f"Estados: {res['estados']}, Municípios: {res['municipios']}. "
              f"Problemas: {'; '.join(res['erros'])}", "erro")
    else:
        flash(f"Base CAPAG atualizada: {res['estados']} estados e "
              f"{res['municipios']} municípios.", "ok")
    return redirect(voltar)


@lic_bp.route("/<int:id>/editar", methods=["GET", "POST"])
@login_required
def editar(id):
    if not current_user.is_assessor():
        abort(403)
    lic = Licitacao.query.get_or_404(id)
    clientes = Cliente.query.order_by(Cliente.nome).all()
    if request.method == "POST":
        data_str = request.form.get("data_disputa", "")
        if data_str:
            try:
                lic.data_disputa = datetime.strptime(data_str, "%Y-%m-%dT%H:%M")
            except ValueError:
                pass
        lic.cliente_id = int(request.form["cliente_id"])
        lic.orgao_licitante = request.form["orgao_licitante"].strip()
        lic.numero_pregao = request.form["numero_pregao"].strip()
        lic.uasg = request.form.get("uasg", "").strip()
        lic.portal = request.form.get("portal", "").strip()
        lic.objeto = request.form.get("objeto", "").strip()
        lic.link_edital = request.form.get("link_edital", "").strip()
        lic.valor_estimado = _valor_form("valor_estimado")
        _aplicar_capag(lic)
        _processar_uploads_form(lic.id)
        db.session.commit()
        flash("Licitacao atualizada.", "ok")
        return redirect(url_for("lic.detalhe", id=lic.id))
    docs_existentes = {d.tipo: d for d in lic.documentos if d.tipo in TIPOS_DOC_LICITACAO_UNICOS}
    return render_template("form_licitacao.html", clientes=clientes,
                           status_choices=STATUS_CHOICES, portal_choices=PORTAL_CHOICES, lic=lic,
                           tipos_doc_unicos=TIPOS_DOC_LICITACAO_UNICOS, docs_existentes=docs_existentes,
                           ufs=UFS, esfera_choices=ESFERA_CHOICES,
                           municipios_uf=municipios_por_uf(lic.uf) if lic.uf else [])


@lic_bp.route("/<int:id>/excluir", methods=["POST"])
@login_required
def excluir(id):
    if not current_user.is_assessor():
        abort(403)
    lic = Licitacao.query.get_or_404(id)
    if lic.empenhos:
        flash("Esta licitação tem empenho(s) cadastrado(s). Exclua os empenhos antes de excluir a licitação.", "erro")
        return redirect(url_for("lic.detalhe", id=lic.id))

    # Vai para a lixeira de licitacoes (30 dias para restaurar), com os arquivos
    from app import lixeira
    lixeira.enviar_licitacao(lic, usuario_id=current_user.id)

    # Remove a pasta de uploads da licitacao, se existir e estiver vazia
    pasta_lic = os.path.join(UPLOAD_FOLDER, str(id))
    try:
        os.rmdir(pasta_lic)
    except OSError:
        pass

    numero_pregao = lic.numero_pregao
    db.session.delete(lic)
    db.session.commit()
    flash(f"Licitação '{numero_pregao}' excluída. Ela fica 30 dias na lixeira e pode ser restaurada.", "ok")
    return redirect(_url_voltar())


@lic_bp.route("/<int:id>/status", methods=["POST"])
@login_required
def atualizar_status(id):
    if not current_user.is_assessor():
        abort(403)
    lic = Licitacao.query.get_or_404(id)
    novo = request.form.get("status")
    # Quando o status e alterado direto pela linha do painel, volta pro painel
    # (mantendo o filtro selecionado); senao volta pro detalhe da licitacao.
    destino = _url_voltar(somente_painel=True) if request.form.get("voltar") == "painel" else url_for("lic.detalhe", id=lic.id)
    if novo not in STATUS_CHOICES:
        return redirect(destino)

    if novo == "homologada":
        valor_str = request.form.get("valor_homologado", "").strip().replace(".", "").replace(",", ".")
        if not valor_str:
            flash("Para marcar como Homologada, informe o valor total homologado.", "erro")
            return redirect(destino)
        try:
            lic.valor_homologado = float(valor_str)
        except ValueError:
            flash("Valor homologado inválido.", "erro")
            return redirect(destino)

    elif novo in ("encerrada", "sem participacao"):
        # mesma coluna guarda o motivo do encerramento ou a justificativa da nao participacao
        motivo = request.form.get("motivo_encerramento", "").strip()
        if not motivo:
            if novo == "encerrada":
                flash("Para marcar como Encerrada, informe o motivo (ex: 2º colocado).", "erro")
            else:
                flash("Para marcar como Sem participação, informe a justificativa (ex: prazo de entrega inviável).", "erro")
            return redirect(destino)
        lic.motivo_encerramento = motivo[:300]

    lic.status = novo
    if novo in ("homologada", "encerrada"):
        # Disputa encerrada: resultados provisorios dos itens viram definitivos
        for item in lic.itens:
            if item.resultado:
                item.resultado_definitivo = True
    db.session.commit()
    rotulos = {"em habilitacao": "Em habilitação", "sem participacao": "Sem participação",
               "interesse nao manifestado": "Interesse não manifestado"}
    flash(f"Status atualizado para '{rotulos.get(novo, novo.capitalize())}'.", "ok")
    return redirect(destino)


@lic_bp.route("/<int:id>/reagendar", methods=["POST"])
@login_required
def reagendar(id):
    """Assessor informa a nova data da disputa. A licitacao passa a aparecer
    no painel e no calendario na data nova; a data original fica guardada."""
    if not current_user.is_assessor():
        abort(403)
    lic = Licitacao.query.get_or_404(id)
    if request.form.get("desfazer") == "1":
        if lic.data_disputa_original:
            lic.data_disputa = lic.data_disputa_original
        lic.data_disputa_original = None
        lic.reagendada_em = None
        db.session.commit()
        flash("Reagendamento desfeito — voltou para a data original.", "ok")
        return redirect(url_for("lic.detalhe", id=lic.id))
    try:
        nova = datetime.strptime(request.form.get("nova_data", ""), "%Y-%m-%dT%H:%M")
    except ValueError:
        flash("Informe a nova data e hora da disputa.", "erro")
        return redirect(url_for("lic.detalhe", id=lic.id))
    if lic.data_disputa_original is None:
        lic.data_disputa_original = lic.data_disputa
    lic.data_disputa = nova
    lic.reagendada_em = datetime.utcnow()
    db.session.commit()
    flash(f"Disputa reagendada para {nova.strftime('%d/%m/%Y às %H:%M')}.", "ok")
    return redirect(url_for("lic.detalhe", id=lic.id))


# ─── Documentos ──────────────────────────────────────────────────────────────

@lic_bp.route("/<int:id>/upload", methods=["POST"])
@login_required
def upload(id):
    if not current_user.is_assessor():
        abort(403)
    lic = Licitacao.query.get_or_404(id)
    # Mesmos campos do formulario de criacao (edital / termo_referencia / outros[]),
    # entao o tipo do documento fica marcado igual, mesmo enviando depois de criada.
    _processar_uploads_form(id)
    db.session.commit()
    flash("Documentos enviados.", "ok")
    return redirect(url_for("lic.detalhe", id=id))


@lic_bp.route("/doc/<int:doc_id>/download")
@login_required
def download_doc(doc_id):
    doc = Documento.query.get_or_404(doc_id)
    lic = Licitacao.query.get_or_404(doc.licitacao_id)
    if not _pode_ver(lic):
        abort(403)
    pasta = os.path.dirname(doc.caminho)
    nome_arquivo = os.path.basename(doc.caminho)
    return send_from_directory(pasta, nome_arquivo, as_attachment=True,
                               download_name=doc.nome_original)


@lic_bp.route("/doc/<int:doc_id>/excluir", methods=["POST"])
@login_required
def excluir_doc(doc_id):
    if not current_user.is_assessor():
        abort(403)
    doc = Documento.query.get_or_404(doc_id)
    lic_id = doc.licitacao_id
    from app import lixeira
    lixeira.enviar_documento(doc, "documento", doc.licitacao.orgao_licitante, usuario_id=current_user.id)
    db.session.delete(doc)
    db.session.commit()
    flash("Documento removido.", "ok")
    return redirect(url_for("lic.detalhe", id=lic_id))


# ─── Itens / Lotes ────────────────────────────────────────────────────────────

def _marcar_preco_registrado(item):
    """Guarda quando e quem registrou o valor minimo do item."""
    from app.models import agora_brasilia
    item.valor_registrado_em = agora_brasilia()
    item.valor_registrado_por = current_user.id


def _avisar_preco_registrado(lic, itens):
    """E-mail pro assessor quando o CLIENTE registra preco (assessor nao avisa a si mesmo)."""
    if current_user.is_assessor():
        return
    try:
        from app.email_service import notificar_preco_registrado
        notificar_preco_registrado(lic, itens, current_user)
    except Exception as e:
        import logging
        logging.getLogger(__name__).error(f"Falha no aviso de preco registrado: {e}")


MSG_TRAVA = "Proposta já cadastrada no portal: os valores mínimos e as marcas estão travados."


def _proposta_travada(lic):
    """Depois do "Proposta cadastrada", valor minimo e marca nao mudam mais."""
    return lic.proposta_cadastrada_em is not None


@lic_bp.route("/<int:id>/proposta-cadastrada", methods=["POST"])
@login_required
def proposta_cadastrada(id):
    """Assessor confirma que cadastrou a proposta no portal (trava os valores do
    cliente) ou reabre, se marcou por engano."""
    if not current_user.is_assessor():
        abort(403)
    lic = Licitacao.query.get_or_404(id)
    if not _pode_ver(lic):
        abort(403)
    if request.form.get("acao") == "reabrir":
        lic.proposta_cadastrada_em = None
        lic.proposta_cadastrada_por = None
        flash("Proposta reaberta: os valores mínimos podem ser alterados de novo.", "ok")
    else:
        from app.models import agora_brasilia
        lic.proposta_cadastrada_em = agora_brasilia()
        lic.proposta_cadastrada_por = current_user.id
        flash("Proposta cadastrada. Os valores mínimos e as marcas do cliente ficaram travados.", "ok")
    db.session.commit()
    return redirect(url_for("lic.detalhe", id=id) + "#parametros-disputa")


@lic_bp.route("/<int:id>/itens/adicionar", methods=["POST"])
@login_required
def adicionar_item(id):
    lic = Licitacao.query.get_or_404(id)
    if not _pode_ver(lic):
        abort(403)
    if _proposta_travada(lic) and (not current_user.is_assessor()
                                   or request.form.get("valor_minimo", "").strip()):
        flash("Proposta já cadastrada no portal: os valores mínimos e as marcas estão travados. Não dá para incluir item com valor mínimo.", "erro")
        return redirect(url_for("lic.detalhe", id=id))
    descricao = request.form.get("descricao", "").strip()
    if not descricao:
        flash("Descricao do item e obrigatoria.", "erro")
        return redirect(url_for("lic.detalhe", id=id))
    valor_str = request.form.get("valor_minimo", "").replace(",", ".")
    valor = None
    try:
        valor = float(valor_str) if valor_str else None
    except ValueError:
        pass
    qtd_str = request.form.get("quantidade", "")
    qtd = None
    try:
        qtd = int(qtd_str) if qtd_str else None
    except ValueError:
        pass
    if valor is not None and not current_user.is_assessor() and not request.form.get("marca", "").strip():
        flash("Preencha a marca do produto para registrar o valor mínimo.", "erro")
        return redirect(url_for("lic.detalhe", id=id))
    item = ItemLicitacao(
        licitacao_id=id,
        numero_item=request.form.get("numero_item", "").strip(),
        descricao=descricao,
        marca=request.form.get("marca", "").strip(),
        lote_grupo=request.form.get("lote_grupo", "").strip(),
        valor_minimo=valor,
        unidade=request.form.get("unidade", "").strip(),
        quantidade=qtd,
    )
    if valor is not None:
        _marcar_preco_registrado(item)
    db.session.add(item)
    db.session.commit()
    if valor is not None:
        _avisar_preco_registrado(lic, [item])
    flash("Item adicionado.", "ok")
    return redirect(url_for("lic.detalhe", id=id))


@lic_bp.route("/item/<int:item_id>/editar", methods=["POST"])
@login_required
def editar_item(item_id):
    item = ItemLicitacao.query.get_or_404(item_id)
    lic = Licitacao.query.get_or_404(item.licitacao_id)
    if not _pode_ver(lic):
        abort(403)
    travada = _proposta_travada(lic)
    tentou_mudar_travado = False
    if travada and not current_user.is_assessor():
        flash("Proposta já cadastrada no portal: os valores mínimos e as marcas estão travados.", "erro")
        return redirect(url_for("lic.detalhe", id=lic.id))
    if travada:
        marca_pedida = request.form.get("marca", "").strip()
        valor_pedido = request.form.get("valor_minimo", "").replace(",", ".").strip()
        try:
            valor_pedido = float(valor_pedido) if valor_pedido else None
        except ValueError:
            valor_pedido = "x"
        valor_atual = float(item.valor_minimo) if item.valor_minimo is not None else None
        tentou_mudar_travado = marca_pedida != (item.marca or "").strip() or valor_pedido != valor_atual
    item.numero_item = request.form.get("numero_item", "").strip()
    item.descricao = request.form.get("descricao", item.descricao).strip()
    if not travada:
        item.marca = request.form.get("marca", "").strip()
    item.lote_grupo = request.form.get("lote_grupo", "").strip()
    item.unidade = request.form.get("unidade", "").strip()
    valor_str = request.form.get("valor_minimo", "").replace(",", ".")
    valor_antes = float(item.valor_minimo) if item.valor_minimo is not None else None
    if not travada:
        try:
            item.valor_minimo = float(valor_str) if valor_str else None
        except ValueError:
            pass
    valor_depois = float(item.valor_minimo) if item.valor_minimo is not None else None
    if valor_depois is not None and not current_user.is_assessor() and not (item.marca or "").strip():
        db.session.rollback()
        flash("Preencha a marca do produto para registrar o valor mínimo.", "erro")
        return redirect(url_for("lic.detalhe", id=lic.id))
    preco_novo = valor_depois is not None and valor_depois != valor_antes
    if preco_novo:
        _marcar_preco_registrado(item)
    elif valor_depois is None and not travada:
        item.valor_registrado_em = None
        item.valor_registrado_por = None
    qtd_str = request.form.get("quantidade", "")
    try:
        item.quantidade = int(qtd_str) if qtd_str else None
    except ValueError:
        pass
    db.session.commit()
    if preco_novo:
        _avisar_preco_registrado(lic, [item])
    if tentou_mudar_travado:
        flash(f"{MSG_TRAVA} Os outros campos foram salvos.", "erro")
    else:
        flash("Item atualizado.", "ok")
    return redirect(url_for("lic.detalhe", id=lic.id))


@lic_bp.route("/item/<int:item_id>/excluir", methods=["POST"])
@login_required
def excluir_item(item_id):
    item = ItemLicitacao.query.get_or_404(item_id)
    lic_id = item.licitacao_id
    lic = Licitacao.query.get_or_404(lic_id)
    if not _pode_ver(lic):
        abort(403)
    if _proposta_travada(lic) and item.valor_minimo is not None:
        flash("Proposta já cadastrada no portal: os valores mínimos e as marcas estão travados. Este item tem valor mínimo e não pode ser excluído.", "erro")
        return redirect(url_for("lic.detalhe", id=lic_id))
    db.session.delete(item)
    db.session.commit()
    flash("Item removido.", "ok")
    return redirect(url_for("lic.detalhe", id=lic_id))


@lic_bp.route("/cnpj/<cnpj>")
@login_required
def buscar_cnpj(cnpj):
    """Consulta CNPJ do vencedor em bases publicas (usado pela tela de resultado)."""
    from flask import jsonify
    from app.resultados import consultar_cnpj, cnpj_valido
    if not current_user.is_assessor():
        abort(403)
    if not cnpj_valido(cnpj):
        return jsonify({"ok": False, "erro": "CNPJ inválido. Confira os números."})
    dados = consultar_cnpj(cnpj)
    if not dados:
        return jsonify({"ok": False, "erro": "Não encontrei esse CNPJ nas bases públicas. Preencha o nome e a UF à mão."})
    return jsonify({"ok": True, **dados})


def _aplicar_resultado(item, lic, venc, escolha="", cnpj="", nome="", uf="", municipio="",
                       justificativa="", marca=""):
    """Grava o resultado de um item. Retorna mensagem de erro (str) ou None se gravou."""
    from app.resultados import so_digitos, cnpj_valido, consultar_cnpj
    from app.models import agora_brasilia
    cnpj = so_digitos(cnpj)
    if cnpj and not cnpj_valido(cnpj):
        return "CNPJ do vencedor inválido. Confira os números."
    cli = lic.cliente
    cnpj_cliente = so_digitos(cli.cnpj) if cli and cli.cnpj else ""
    minimo = float(item.valor_minimo) if item.valor_minimo is not None else None

    resultado, just = None, None
    if cnpj and cnpj_cliente and cnpj == cnpj_cliente:
        resultado = "vitoria"  # a proposta vencedora e do proprio cliente
    elif minimo is None:
        resultado = "sem_lance"
    elif venc >= minimo:
        if escolha == "vitoria":
            resultado = "vitoria"
        elif escolha == "justificar":
            if not justificativa:
                return "Escreva a justificativa: por que o cliente não venceu com valor melhor?"
            resultado, just = "derrota_justificada", justificativa
        else:
            return "Escolha Vitória ou Justificar."
    else:
        resultado = "derrota"

    if resultado == "vitoria":
        cnpj = cnpj_cliente
        nome, uf, municipio = (cli.nome if cli else ""), (cli.estado or ""), (cli.cidade or "")
        marca = marca or item.marca or ""
    elif cnpj and not nome:
        dados = consultar_cnpj(cnpj)
        if dados:
            nome, uf, municipio = dados["nome"], dados["uf"], dados["municipio"]

    item.resultado = resultado
    item.resultado_justificativa = just
    item.diferenca_pct = round((minimo - venc) / venc * 100, 2) if minimo is not None else None
    item.valor_vencedor = venc
    item.vencedor_cnpj = cnpj or None
    item.vencedor_nome = (nome or "").strip() or None
    item.vencedor_uf = (uf or "").strip().upper()[:2] or None
    item.vencedor_municipio = (municipio or "").strip() or None
    item.vencedor_marca = (marca or "").strip()[:200] or None
    item.resultado_definitivo = lic.status in ("homologada", "encerrada")
    item.resultado_em = agora_brasilia()
    item.resultado_por = current_user.id
    return None


@lic_bp.route("/item/<int:item_id>/resultado", methods=["POST"])
@login_required
def salvar_resultado(item_id):
    """Assessor registra o resultado do item: valor vencedor e, conforme o caso,
    vitoria / justificativa / CNPJ do vencedor."""
    from app.resultados import parse_valor
    if not current_user.is_assessor():
        abort(403)
    item = ItemLicitacao.query.get_or_404(item_id)
    lic = Licitacao.query.get_or_404(item.licitacao_id)
    voltar = request.referrer or url_for("lic.detalhe", id=lic.id)

    if request.form.get("acao") == "limpar":
        for campo in ("resultado", "valor_vencedor", "diferenca_pct", "vencedor_cnpj", "vencedor_nome",
                      "vencedor_uf", "vencedor_municipio", "vencedor_marca", "resultado_justificativa",
                      "resultado_em", "resultado_por"):
            setattr(item, campo, None)
        item.resultado_definitivo = False
        db.session.commit()
        flash("Resultado do item apagado.", "ok")
        return redirect(voltar)

    venc = parse_valor(request.form.get("valor_vencedor"))
    if venc is None:
        flash("Informe o valor vencedor do item.", "erro")
        return redirect(voltar)
    erro = _aplicar_resultado(
        item, lic, venc,
        escolha=request.form.get("escolha", ""),
        cnpj=request.form.get("vencedor_cnpj", ""),
        nome=request.form.get("vencedor_nome", ""),
        uf=request.form.get("vencedor_uf", ""),
        municipio=request.form.get("vencedor_municipio", ""),
        justificativa=(request.form.get("justificativa") or "").strip(),
        marca=request.form.get("vencedor_marca", ""),
    )
    if erro:
        db.session.rollback()
        flash(erro, "erro")
        return redirect(voltar)
    db.session.commit()
    flash("Resultado do item salvo.", "ok")
    return redirect(voltar)


# ─── Leitura de proposta em PDF ───────────────────────────────────────────────

def _pasta_propostas_tmp(lic_id):
    pasta = os.path.join(UPLOAD_FOLDER, str(lic_id), "propostas_tmp")
    os.makedirs(pasta, exist_ok=True)
    return pasta


def _num_item(txt):
    t = (txt or "").strip().lower().replace("item", "").strip()
    return t.lstrip("0") or ("0" if t else "")


@lic_bp.route("/<int:id>/proposta/ler", methods=["POST"])
@login_required
def ler_proposta_pdf(id):
    """Le o PDF da proposta vencedora e devolve uma previa (itens, valores, marca, licitante)."""
    from flask import jsonify
    from app.proposta_pdf import ler_proposta
    from app.resultados import consultar_cnpj, formatar_cnpj, so_digitos
    if not current_user.is_assessor():
        abort(403)
    lic = Licitacao.query.get_or_404(id)
    f = request.files.get("proposta")
    if not f or not f.filename.lower().endswith(".pdf"):
        return jsonify({"ok": False, "erro": "Envie a proposta em PDF."})
    token = uuid.uuid4().hex
    caminho = os.path.join(_pasta_propostas_tmp(id), token + ".pdf")
    f.save(caminho)
    with open(caminho + ".nome", "w", encoding="utf-8") as fn:
        fn.write(f.filename)

    lido = ler_proposta(caminho)
    if not lido.get("ok"):
        return jsonify({"ok": False, "erro": lido.get("erro")})

    cnpj = lido.get("cnpj") or ""
    dados = consultar_cnpj(cnpj) if cnpj else None
    licitante = {
        "cnpj": formatar_cnpj(cnpj) if cnpj else "",
        "nome": (dados or {}).get("nome") or lido.get("nome_pdf") or "",
        "uf": (dados or {}).get("uf") or "",
        "municipio": (dados or {}).get("municipio") or "",
        "fonte": (dados or {}).get("fonte") or ("PDF" if lido.get("nome_pdf") else ""),
    }
    cnpj_cliente = so_digitos(lic.cliente.cnpj) if lic.cliente and lic.cliente.cnpj else ""
    e_cliente = bool(cnpj and cnpj_cliente and cnpj == cnpj_cliente)

    por_numero = {}
    for it in lic.itens:
        por_numero.setdefault(_num_item(it.numero_item), it)
    item_clicado = request.form.get("item_id", type=int)

    itens = []
    for p in lido["itens"]:
        it = por_numero.get(_num_item(p["numero"]))
        if not it or not p.get("unit"):
            itens.append({"numero": p["numero"], "item_id": None, "unit": p.get("unit"), "marca": p.get("marca"),
                          "previsto": "nao_encontrado"})
            continue
        minimo = float(it.valor_minimo) if it.valor_minimo is not None else None
        if e_cliente:
            previsto = "vitoria"
        elif minimo is None:
            previsto = "sem_lance"
        elif p["unit"] < minimo:
            previsto = "derrota"
        else:
            previsto = "justificar"
        itens.append({
            "numero": p["numero"], "item_id": it.id, "descricao": (it.descricao or "")[:90],
            "minimo": minimo, "qtd": p.get("qtd") or it.quantidade, "unit": p["unit"], "total": p.get("total"),
            "marca": p.get("marca") or "", "previsto": previsto,
            "diferenca": round((minimo - p["unit"]) / p["unit"] * 100, 2) if minimo is not None else None,
            "ja_tem": bool(it.resultado),
            "marcar": (minimo is not None) or it.id == item_clicado,
        })
    return jsonify({"ok": True, "token": token, "licitante": licitante, "e_cliente": e_cliente, "itens": itens})


@lic_bp.route("/<int:id>/proposta/aplicar", methods=["POST"])
@login_required
def aplicar_proposta_pdf(id):
    """Grava os resultados escolhidos na previa e anexa o PDF da proposta a licitacao."""
    from app.resultados import parse_valor
    if not current_user.is_assessor():
        abort(403)
    lic = Licitacao.query.get_or_404(id)
    voltar = request.referrer or url_for("lic.detalhe", id=id)
    token = re.sub(r"[^0-9a-f]", "", request.form.get("token", ""))
    caminho_tmp = os.path.join(_pasta_propostas_tmp(id), token + ".pdf")
    if not token or not os.path.exists(caminho_tmp):
        flash("A leitura da proposta expirou. Envie o PDF de novo.", "erro")
        return redirect(voltar)

    cnpj = request.form.get("cnpj", "")
    nome = request.form.get("nome", "")
    uf = request.form.get("uf", "")
    municipio = request.form.get("municipio", "")
    ids = [int(x) for x in request.form.getlist("item_ids") if x.isdigit()]
    gravados, pulados = 0, []
    for item in ItemLicitacao.query.filter(ItemLicitacao.licitacao_id == id, ItemLicitacao.id.in_(ids)).all():
        venc = parse_valor(request.form.get(f"unit_{item.id}"))
        if venc is None:
            pulados.append(item.numero_item or str(item.id))
            continue
        just = (request.form.get(f"just_{item.id}") or "").strip()
        erro = _aplicar_resultado(item, lic, venc,
                                  escolha=request.form.get(f"escolha_{item.id}", "justificar" if just else ""),
                                  cnpj=cnpj, nome=nome, uf=uf, municipio=municipio,
                                  justificativa=just, marca=request.form.get(f"marca_{item.id}", ""))
        if erro:
            pulados.append(item.numero_item or str(item.id))
            continue
        gravados += 1

    # anexa a proposta aos documentos da licitacao
    try:
        nome_original = "proposta.pdf"
        if os.path.exists(caminho_tmp + ".nome"):
            with open(caminho_tmp + ".nome", encoding="utf-8") as fn:
                nome_original = fn.read().strip() or nome_original
            os.remove(caminho_tmp + ".nome")
        pasta = os.path.join(UPLOAD_FOLDER, str(id))
        destino = os.path.join(pasta, f"{uuid.uuid4().hex}.pdf")
        os.replace(caminho_tmp, destino)
        if not nome_original.lower().startswith("proposta"):
            nome_original = f"Proposta - {nome_original}"
        db.session.add(Documento(licitacao_id=id, categoria="processo", tipo="outros",
                                 nome_original=nome_original[:300], caminho=destino,
                                 tamanho=os.path.getsize(destino), enviado_por=current_user.id))
    except Exception as e:
        import logging
        logging.getLogger(__name__).error(f"Falha ao anexar proposta: {e}")

    db.session.commit()
    msg = f"{gravados} item(ns) preenchido(s) pela proposta de {(nome or 'licitante').strip()}."
    if pulados:
        msg += f" Ficaram de fora (falta valor ou justificativa): item(ns) {', '.join(pulados)}."
    flash(msg, "ok" if gravados else "erro")
    return redirect(voltar)


@lic_bp.route("/<int:id>/itens/excluir-selecionados", methods=["POST"])
@login_required
def excluir_itens_selecionados(id):
    lic = Licitacao.query.get_or_404(id)
    if not _pode_ver(lic):
        abort(403)
    ids = [int(x) for x in request.form.getlist("item_ids") if x.isdigit()]
    if not ids:
        flash("Nenhum item selecionado.", "erro")
        return redirect(url_for("lic.detalhe", id=id))
    itens = ItemLicitacao.query.filter(ItemLicitacao.licitacao_id == id, ItemLicitacao.id.in_(ids)).all()
    if _proposta_travada(lic):
        presos = [i for i in itens if i.valor_minimo is not None]
        if presos:
            flash(f"{MSG_TRAVA} {len(presos)} item(ns) com valor mínimo não foram excluídos.", "erro")
        itens = [i for i in itens if i.valor_minimo is None]
    for item in itens:
        db.session.delete(item)
    db.session.commit()
    flash(f"{len(itens)} item(ns) removido(s).", "ok")
    return redirect(request.referrer or url_for("lic.detalhe", id=id))


# ─── Documentos de Apoio (cliente) ────────────────────────────────────────────

EXTENSOES_APOIO_PERMITIDAS = {
    ".pdf", ".html", ".htm", ".ppt", ".pptx", ".xls", ".xlsx", ".csv", ".txt"
}


@lic_bp.route("/<int:id>/apoio/upload", methods=["POST"])
@login_required
def upload_apoio(id):
    lic = Licitacao.query.get_or_404(id)
    if current_user.is_assessor() or lic.cliente_id != current_user.cliente_id:
        abort(403)
    arquivos = request.files.getlist("arquivos")
    nome_personalizado = request.form.get("nome_personalizado", "").strip()
    enviados = 0
    for f in arquivos:
        if not f.filename:
            continue
        ext = os.path.splitext(f.filename)[1].lower()
        if ext not in EXTENSOES_APOIO_PERMITIDAS:
            flash(f"Tipo de arquivo não permitido: {f.filename}. "
                  "Use PDF, HTML, PPT, XLS, CSV ou TXT.", "erro")
            continue
        caminho = _salvar_arquivo(f, id)
        # Se o cliente renomeou o arquivo, usa o nome dado (mantendo a extensao original)
        if nome_personalizado and len(arquivos) == 1:
            nome_exibido = nome_personalizado
            if not nome_exibido.lower().endswith(ext):
                nome_exibido += ext
        else:
            nome_exibido = f.filename
        doc = Documento(
            licitacao_id=id,
            categoria="apoio",
            tipo="outros",
            nome_original=nome_exibido,
            caminho=caminho,
            tamanho=os.path.getsize(caminho),
            enviado_por=current_user.id,
        )
        db.session.add(doc)
        enviados += 1
    if enviados:
        db.session.commit()
        flash("Documento(s) de apoio enviado(s).", "ok")
    return redirect(url_for("lic.detalhe", id=id))


@lic_bp.route("/apoio/<int:doc_id>/excluir", methods=["POST"])
@login_required
def excluir_doc_apoio(doc_id):
    doc = Documento.query.get_or_404(doc_id)
    lic = Licitacao.query.get_or_404(doc.licitacao_id)
    if doc.categoria != "apoio":
        abort(404)
    if current_user.is_assessor() or lic.cliente_id != current_user.cliente_id:
        abort(403)
    lic_id = doc.licitacao_id
    from app import lixeira
    lixeira.enviar_documento(doc, "documento_apoio", lic.orgao_licitante, usuario_id=current_user.id)
    db.session.delete(doc)
    db.session.commit()
    flash("Documento de apoio removido.", "ok")
    return redirect(url_for("lic.detalhe", id=lic_id))


@lic_bp.route("/<int:id>/apoio/observacao", methods=["POST"])
@login_required
def adicionar_observacao_apoio(id):
    lic = Licitacao.query.get_or_404(id)
    if not _pode_ver(lic):
        abort(403)
    texto = request.form.get("texto", "").strip()
    if not texto:
        flash("Escreva algo antes de enviar.", "erro")
        return redirect(url_for("lic.detalhe", id=id))
    obs = ObservacaoApoio(licitacao_id=id, autor_id=current_user.id, texto=texto)
    db.session.add(obs)
    db.session.commit()
    flash("Observação enviada.", "ok")
    return redirect(url_for("lic.detalhe", id=id))


# ─── Comentários ──────────────────────────────────────────────────────────────

@lic_bp.route("/<int:id>/comentar", methods=["POST"])
@login_required
def comentar(id):
    lic = Licitacao.query.get_or_404(id)
    if not _pode_ver(lic):
        abort(403)
    texto = request.form.get("texto", "").strip()
    if not texto:
        flash("Escreva algo antes de enviar.", "erro")
        return redirect(url_for("lic.detalhe", id=id))
    comentario = ComentarioLicitacao(
        licitacao_id=id,
        autor_id=current_user.id,
        texto=texto,
    )
    from app.models import agora_brasilia
    if current_user.is_assessor():
        lic.comentario_cliente_pendente_em = None  # assessor respondeu = ja viu
    else:
        lic.comentario_cliente_pendente_em = agora_brasilia()
    db.session.add(comentario)
    db.session.commit()
    from app.email_service import notificar_novo_comentario, notificar_comentario_cliente
    try:
        if current_user.is_assessor():
            notificar_novo_comentario(comentario, lic)   # assessor -> cliente
        else:
            notificar_comentario_cliente(comentario, lic)  # cliente -> assessor
    except Exception:
        pass  # Nao trava o comentario se o e-mail falhar
    flash("Comentário enviado.", "ok")
    return redirect(url_for("lic.detalhe", id=id))


@lic_bp.route("/comentario/<int:comentario_id>/editar", methods=["POST"])
@login_required
def editar_comentario(comentario_id):
    comentario = ComentarioLicitacao.query.get_or_404(comentario_id)
    if not current_user.is_assessor() or comentario.autor_id != current_user.id:
        abort(403)
    texto = request.form.get("texto", "").strip()
    if not texto:
        flash("O comentário não pode ficar vazio.", "erro")
        return redirect(url_for("lic.detalhe", id=comentario.licitacao_id))
    comentario.texto = texto
    comentario.editado_em = datetime.utcnow()
    db.session.commit()
    flash("Comentário atualizado.", "ok")
    return redirect(url_for("lic.detalhe", id=comentario.licitacao_id))


@lic_bp.route("/comentario/<int:comentario_id>/excluir", methods=["POST"])
@login_required
def excluir_comentario(comentario_id):
    comentario = ComentarioLicitacao.query.get_or_404(comentario_id)
    if not current_user.is_assessor() or comentario.autor_id != current_user.id:
        abort(403)
    lic_id = comentario.licitacao_id
    db.session.delete(comentario)
    db.session.commit()
    flash("Comentário removido.", "ok")
    return redirect(url_for("lic.detalhe", id=lic_id))


# ─── Resumo com IA ───────────────────────────────────────────────────────────

# Extensoes de PDF sao enviadas como documento nativo para a API (ela le PDF
# diretamente). As demais extensoes suportadas tem o texto extraido aqui no
# servidor antes de ir para o prompt.
EXTENSOES_TEXTO_SUPORTADAS = {".docx", ".xlsx", ".xlsm", ".csv", ".html", ".htm", ".txt"}


def _montar_conteudo_resumo(lic):
    """Monta a lista de blocos de conteudo (texto + documentos PDF nativos)
    enviados a API, a partir dos documentos anexados a licitacao
    (edital, termo_referencia, outros)."""
    from app.doc_extractor import extrair_texto_documento, ler_pdf_base64

    blocos = []
    textos_extraidos = []
    pdfs_anexados = 0
    arquivos_ignorados = []

    for doc in lic.documentos:
        if doc.tipo not in ("edital", "termo_referencia", "outros"):
            continue
        ext = os.path.splitext(doc.nome_original)[1].lower()
        if ext == ".pdf":
            b64 = ler_pdf_base64(doc)
            if b64:
                blocos.append({
                    "type": "document",
                    "source": {"type": "base64", "media_type": "application/pdf", "data": b64},
                    "title": doc.nome_original,
                })
                pdfs_anexados += 1
            else:
                arquivos_ignorados.append(doc.nome_original)
        elif ext in EXTENSOES_TEXTO_SUPORTADAS:
            texto = extrair_texto_documento(doc)
            if texto:
                textos_extraidos.append(f"\n--- Conteudo de {doc.nome_original} ---\n{texto}")
            else:
                arquivos_ignorados.append(doc.nome_original)
        else:
            arquivos_ignorados.append(doc.nome_original)

    return blocos, "\n".join(textos_extraidos), pdfs_anexados, arquivos_ignorados


@lic_bp.route("/<int:id>/salvar-resumo", methods=["POST"])
@login_required
def salvar_resumo(id):
    if not current_user.is_assessor():
        abort(403)
    lic = Licitacao.query.get_or_404(id)
    lic.resumo_ia = (request.form.get("resumo", "") or "").strip() or None
    db.session.commit()
    flash("Resumo salvo.", "ok")
    return redirect(url_for("lic.detalhe", id=id))


@lic_bp.route("/<int:id>/resumo-ia", methods=["POST"])
@login_required
def gerar_resumo(id):
    if not current_user.is_assessor():
        abort(403)
    lic = Licitacao.query.get_or_404(id)

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        flash("Chave de API da Anthropic não configurada no servidor. Avise o suporte técnico.", "erro")
        return redirect(url_for("lic.detalhe", id=id))

    palavras_chave = [p.palavra for p in lic.cliente.palavras_chave] if lic.cliente else []

    blocos_documento, texto_extraido, pdfs_anexados, arquivos_ignorados = _montar_conteudo_resumo(lic)

    if not blocos_documento and not texto_extraido:
        flash("Nenhum documento legível foi encontrado (Edital, Termo de Referência ou Outros). "
              "Anexe ao menos um arquivo PDF, DOCX, XLSX, CSV ou HTML antes de gerar o resumo.", "erro")
        return redirect(url_for("lic.detalhe", id=id))

    itens_cadastrados = "\n".join(
        f"- {item.descricao} | Marca: {item.marca or '-'} | Lote/Grupo: {item.lote_grupo or '-'} | "
        f"Qtd: {item.quantidade or '-'} {item.unidade or ''} | Valor mínimo: "
        f"{('R$ ' + str(item.valor_minimo)) if item.valor_minimo else 'não informado'}"
        for item in lic.itens
    ) or "Nenhum item cadastrado manualmente no sistema."

    palavras_txt = ", ".join(palavras_chave) if palavras_chave else "(nenhuma palavra-chave cadastrada para este cliente)"

    instrucoes = f"""Você é um especialista em licitações públicas brasileiras, ajudando uma consultoria a
analisar uma oportunidade para seu cliente.

DADOS DO PROCESSO (cadastrados no sistema):
Órgão: {lic.orgao_licitante}
Pregão: {lic.numero_pregao}
UASG: {lic.uasg or 'não informado'}
Portal: {lic.portal or 'não informado'}
Data da disputa: {lic.data_disputa.strftime('%d/%m/%Y %H:%M') if lic.data_disputa else 'não informada'}
Objeto (cadastrado): {lic.objeto or 'não informado'}

ITENS CADASTRADOS MANUALMENTE NO SISTEMA (podem ser parciais ou estar ausentes):
{itens_cadastrados}

PALAVRAS-CHAVE DE INTERESSE DESTE CLIENTE:
{palavras_txt}

Os documentos anexados (edital, termo de referência e/ou outros arquivos) estão inclusos abaixo
ou em anexo a esta mensagem. Leia-os com atenção e produza um resumo executivo em português,
direto e objetivo, com EXATAMENTE estas seções, usando estes títulos:

## Itens Relacionados ao Interesse do Cliente
Liste apenas os itens/lotes do edital ou termo de referência cuja DESCRIÇÃO contenha (mesmo que
parcialmente ou com sinônimo próximo) alguma das palavras-chave de interesse listadas acima.
Para cada item relacionado, informe: descrição, número do item/lote, quantidade e valor estimado
(se disponível no documento). Se nenhuma palavra-chave foi cadastrada para este cliente, ou se
nenhum item corresponder, diga isso explicitamente nesta seção.

## Modo de Disputa
Informe o modo de disputa (ex: aberto, fechado, aberto e fechado, menor preço, melhor técnica etc.),
se ha lotes/grupos ou itens isolados, e qualquer regra relevante de julgamento encontrada no edital.

## Prazo de Pagamento
Informe o prazo de pagamento ao fornecedor descrito no edital/termo de referência (ex: "30 dias após
liquidação da nota fiscal"). Se não encontrar essa informação no documento, diga isso explicitamente.

## Requisitos de Habilitação e Qualificação Técnica
Resuma os principais requisitos de habilitação/qualificação técnica exigidos (atestados de capacidade
técnica, registros, certidões específicas, patrimônio mínimo etc.) que sejam relevantes para a decisão
de participar.

## Pontos de Atenção
Quaisquer prazos, riscos ou exigências que mereçam atenção especial do cliente ou do assessor.

Seja direto, use bullet points quando fizer sentido, e NÃO invente informação que não esteja nos
documentos ou dados acima — se não encontrar algo, diga que não foi encontrado no documento.

FORMATAÇÃO (importante, será renderizada como Markdown):
- Use "##" para os títulos das seções acima (exatamente como escritos).
- Sempre deixe uma linha vazia antes de iniciar uma lista com "-" e uma linha vazia depois da lista.
- Não use "---" (linha horizontal) para separar itens dentro de uma lista — use apenas entre seções,
  se necessário, e sempre com linha vazia antes e depois.
- Não coloque mais de uma informação por linha de lista; cada "-" deve estar em sua própria linha,
  separada por quebra de linha real (não use "\\n" literal nem junte itens na mesma linha)."""

    if texto_extraido:
        instrucoes += f"\n\n--- TEXTO EXTRAÍDO DOS DOCUMENTOS ANEXADOS (não-PDF) ---\n{texto_extraido}"

    conteudo_mensagem = blocos_documento + [{"type": "text", "text": instrucoes}]

    try:
        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "Content-Type": "application/json",
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
            },
            json={
                "model": "claude-sonnet-4-6",
                "max_tokens": 1500,
                "messages": [{"role": "user", "content": conteudo_mensagem}],
            },
            timeout=90,
        )
        data = resp.json()
        if resp.status_code != 200:
            erro_msg = data.get("error", {}).get("message", str(data))
            resumo = f"Erro ao gerar resumo (HTTP {resp.status_code}): {erro_msg}"
        else:
            resumo = "".join(
                bloco.get("text", "") for bloco in data.get("content", []) if bloco.get("type") == "text"
            )
            if arquivos_ignorados:
                resumo += ("\n\n---\n*Observação: os seguintes arquivos não puderam ser lidos e foram "
                          f"ignorados nesta análise: {', '.join(arquivos_ignorados)}.*")
    except Exception as e:
        resumo = f"Erro ao gerar resumo: {str(e)}"

    lic.resumo_ia = resumo
    db.session.commit()
    flash("Resumo gerado com sucesso.", "ok")
    return redirect(url_for("lic.detalhe", id=id))


# ─── Favoritos (cada usuario tem os seus) ────────────────────────────────────

@lic_bp.route("/<int:id>/favoritar", methods=["POST"])
@login_required
def favoritar(id):
    from app.models import FavoritoLicitacao
    lic = Licitacao.query.get_or_404(id)
    if not _pode_ver(lic):
        abort(403)
    fav = FavoritoLicitacao.query.filter_by(user_id=current_user.id, licitacao_id=lic.id).first()
    if fav:
        db.session.delete(fav)
        favorita = False
    else:
        db.session.add(FavoritoLicitacao(user_id=current_user.id, licitacao_id=lic.id))
        favorita = True
    db.session.commit()
    if request.headers.get("X-Requested-With") == "fetch":
        return jsonify({"favorita": favorita})
    return redirect(request.referrer or url_for("lic.detalhe", id=lic.id))
